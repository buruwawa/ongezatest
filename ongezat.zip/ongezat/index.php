<!DOCTYPE html>
<html lang="en">
<head>
<title>Buruhani wawa-Online Test</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/fullcalendar.css" />
<link rel="stylesheet" href="css/maruti-style.css" />
<link rel="stylesheet" href="css/maruti-media.css" class="skin-color" />
</head>
<body>

<!--Header-part-->
<div id="header">
  <!-- <h1><a href="dashboard.html">Buruhani wawa-Online Test</a></h1> -->
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
       <li class=""><a title="" href="login.html"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--close-top-Header-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a><ul>
    <li class="active"><a href="index.html"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
   
   
  </ul>
</div>
<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  </div>
  <div class="container-fluid">   
    <div class="row-fluid">
      <div class="widget-box">
        <div class="widget-title"><span class="icon"><i class="icon-tasks"></i></span>
          <h6>Ongeza test: <strong style="color:green;">Click the Question button to view the Answer</strong></h6>
        </div>


        <div class="widget-content">
          <div class="row-fluid">
<div class="span6">
        <div class="accordion" id="collapse-group">
          <div class="accordion-group widget-box">
            <div class="accordion-heading">
              <div class="widget-title"> <a data-parent="#collapse-group" href="#collapseGOne" data-toggle="collapse"> <span class="icon"><i class="#"></i>1:</span>
                <h5>Question 1:  <i style="color:red">=> Click Me</i></h5>
                </a> </div>
            </div>
            <div class="collapse in accordion-body" id="collapseGOne">
              <div class="widget-content">
                 <i style="color:blue">please type any string in the text box to see it's output.</i>

                 <form action="" method="post">
                 <div class="control-group">
                    <hr>
                      <div class="controls">
                        <input type="text" id="s" name="s" maxlength="104" minlength="1" value=""/>
                          <input id="ok" name="ok" class="btn btn-primary" type="submit" value="Reverse Sentence" />
                          <!-- <button id="ok" name="ok" type="submit">vvv</button> -->
                      </div>
                    </div>

                     <div class="control-group">
                      <label class="control-label" style="color:red;">Output!</label>
                      <div class="controls">
<?php
if(isset($_POST['ok'])){
 $s=$_POST['s'];

function reverseString($s)
{
$i = 0;
$new_str="";//New String
$spc="";//Space between words
$nw="";//number of words plus emptyspace

while( $nw = @$s[$i] )
{
    if($nw == " "){

       $spc = " ".$new_str.$spc;
       $new_str = "";
       $new_str.=$nw;
    }else{
       $new_str.=$nw;
    }
    $i++;
}

 return $new_str.$spc;
}

echo reverseString($s);
}
?>
                      </div>
                    </div>
                </form>
                     <hr>
              </div>

            </div>
          </div>
        </div>
      </div>

      <div class="span6">
        <div class="widget-box collapsible">
          <div class="widget-title"> <a data-toggle="collapse" href="#collapseOne"> <span class="icon"><i class="#"></i>2:</span>
              <h5>Question 2:  <i style="color:red">=> Click Me</i></h5>
            </a> </div>
          <div id="collapseOne" class="collapse in">
            <div class="widget-content">

<form action="" method="POST">
<!-- <input type="text" name="tbox[]"> -->
<input type="text" name="var1" placeholder="Eaxmple: 2,3,5,6" required>
<input type="text" name="var2" placeholder="array list2" required>
<input type="text" name="var3" placeholder="array list3" required>
<input type="text" name="var4" placeholder="array list4" required>
 <input id="action" name="action" class="btn btn-primary" type="submit" value="Sum of Diagonals" />
</form>

<?php
$a=91;
  $m=[];
// for ($x = 0; $x <= 8; $x++) {
//   echo "The number is: $x <br>";
// } 

if(isset($_POST['action']))
{
 
  $a=$_POST['var1'];
  $b=$_POST['var2'];
  $c=$_POST['var3'];
  $d=$_POST['var4'];

  $a = explode(",", $a);
  $b = explode(",", $b);
  $c = explode(",", $c);
  $d = explode(",", $d);
  // echo $a[];
     //print_r($a);
      //print_r($b); 
       //print_r($c); 
        //print_r($d);
       echo json_encode($a);
        echo "<br>";
       echo json_encode($b);
        echo "<br>";
       echo json_encode($c);
        echo "<br>";
       echo json_encode($d);
         echo "<br>";  
 echo "<hr>";

$m=array(($a),
        ($b),
        ($c),
        ($d));
   
$i=0;
$j=0;   

$es=count($m)-1;
for($i=0;$i<count($m);$i++)
    {
      for($j=0;$j<count($m);$j++)
        {
           echo $m[$i][$j]." ";
        }
       echo "<br>";
    }
  }
"</br>";

printDiagonalSums($m, count($m));
function printDiagonalSums($mat, $n) 
{ 
   // global $MAX; 
    $mainD = 0; $secondary = 0;  
    for ($i = 0; $i < $n; $i++)  
    { 
         $mainD += $mat[$i][$i]; 
        // $secondary += $mat[$i][$n - $i - 1];     
    }   
 // echo json_decode($mainD);
    echo "Answer:" ,  
               json_encode($mainD),"\n"; 
} 

$arr = array( 1,1,2, 2, 4, 5 );
//$a = $a;
// foreach(array_unique($arr) as $val => $c)
//     if($c > 1) $arr[] = $val;
// // function return_dup($arrayx);
  // print_r($a);

  function return_dup( $a ) {
    $dups = array();
    $temp = $a;

   
    foreach ( $a as $key => $item ) {
        unset( $temp[$key] );
        if ( in_array( $item, $temp ) ) {
            $dups[] = $item;
        }
    }
  
    return $dups;
}
var_export(count(return_dup($a)));
?>

            </div>
          </div>
         
          <div id="collapseThree" class="collapse">
            <div class="widget-content"> This box is now open </div>
          </div>
        </div>
      </div>
         
   <div class="span6">
        <div class="widget-box collapsible">
          <div class="widget-title"> <a data-toggle="collapse" href="#collapsetwo"> <span class="icon"><i class="#"></i>3:</span>
              <h5>Question 3:  <i style="color:red">=> Click Me</i></h5>
            </a> </div>
          <div id="collapsetwo" class="collapse in">
            <div class="widget-content">

<form action="" method="POST">
<!-- <input type="text" name="tbox[]"> -->
<input type="text" name="perm1" placeholder="Eaxmple: 2,3,5,6" required>
<input type="number" name="perm2" maxlength="500" minlength="1" placeholder="target no Eaxmple 7" required>

 <input id="permutation" name="permutation" class="btn btn-primary" type="submit" value="Commbination" />
</form>

<?php
require_once("Combinations.php");
$a=91;
// for ($x = 0; $x <= 8; $x++) {
//   echo "The number is: $x <br>";
// } 


if(isset($_POST['permutation']))
{
 //$arr = array(1,2,4,5);
//$arr=array($_POST['perm1']);
 $a=$_POST['perm1'];
$a = explode(",", $a);
$arr=$a;

 function permutation(array $arr)
{
    while($ele=array_shift($arr))
    {
        $x=$ele;
        //echo "[".$x."\n";
        foreach($arr as $rest)
        {
            $x.=" $rest";
            echo $x."\n],";
            "</br>";
        }
    }
}
//permutation($arr);
 }
"</br>";

// initialize Combinations class
$Combinations = new Combinations($arr);
  

for($n=1;$n<=count($arr);$n++){    
$combinations = $Combinations->getCombinations($n, true);
  
  $js=json_encode($combinations);
  $jsf=json_decode($js);


if(isset($_POST['permutation']))
{
foreach ($jsf as $item) {
  $sum = 0;
  foreach ($item as $keys=>$key) {
$sum += $item[$keys];   
  }
  if($sum==$_POST['perm2'])
  {
   $js_item=json_encode($item);
    echo $js_item."\n=>"; 
    echo $sum."\n,";  
  }
}
}
 }
 
?>

            </div>
          </div>
         
          <div id="collapseThree" class="collapse">
            <div class="widget-content"> This box is now open </div>
          </div>
        </div>
      </div>


  <div class="span6">
        <div class="widget-box collapsible">
          <div class="widget-title"> <a data-toggle="collapse" href="#collapsethree"> <span class="icon"><i class="#"></i>4:</span>
              <h5>Question 4:  <i style="color:red">=> Click Me</i></h5>
            </a> </div>
          <div id="collapsethree" class="collapse in">
            <div class="widget-content">

<form action="" method="POST">
<!-- <input type="text" name="tbox[]"> -->
<input type="text" name="arrList" placeholder="array list:[1,2,2,3,4,5]" required>
 <input id="arrListr" name="arrListr" class="btn btn-primary" type="submit" value="Intervals" />
</form>

<?php

if(isset($_POST['arrListr']))
{
$a=$_POST['arrList'];
$a = explode("]", $a);
$arr=$a;
// print_r($arr);

function eraseOverlapIntervals($intervals)
{
   // $combined = array_merge($array1,$array2);
    $counted = array_count_values($intervals);
    $dupes = [];
    $keys = array_keys($counted);
    foreach ($keys as $key)
    {   
        if ($counted[$key] > 1)
        {$dupes[] = $key;}
    }
    sort($dupes);
    return $dupes;
}

$intervals = $arr;
$dupes = eraseOverlapIntervals($intervals);
print_r(count($dupes)); 
 
 echo "<hr>";
  }
"</br>";


// $arr = array( 1,1,2, 2, 4, 5 );
//$a = $a;
// foreach(array_unique($arr) as $val => $c)
//     if($c > 1) $arr[] = $val;
// // function return_dup($arrayx);
  // print_r($a);

  
?>

            </div>
          </div>
         
          <div id="collapseThree" class="collapse">
            <div class="widget-content"> This box is now open </div>
          </div>
        </div>
      </div>
          </div>
        </div>
      </div>
    </div>
    
  </div>
</div>
</div>
</div>
<div class="row-fluid">
  <div id="footer" class="span12"> 2012 &copy; Marutii Admin. Brought to you by <a href="http://themedesigner.in">Themedesigner.in</a> </div>
</div>
<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/maruti.js"></script> 
<script src="js/maruti.dashboard.js"></script> 
<script src="js/maruti.chat.js"></script> 
 

<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
