
    <div id="sidebar"><a href="#" class="visible-phone">

      <i class="icon icon-home"></i> Dashboard</a>
        <ul>
          
            <li class=" dropdown" id="login"><a href="dashboard.php"><i class="icon icon-home"></i> <span>Dashboard</span> <b class="caret"></b></a>
                <ul class="dropdown-menu">
                       <li class="divider"></li>
                   <li><a href="dashboard.php">General dashboard</a></li>
                      <li class="divider"></li>
                    <li><a href="customer.php">Sub-dashboard</a></li>
                       <li class="divider"></li>
                </ul>
            </li>

              <li class=" dropdown" id="login"><a href="#"><i class="icon icon-envelope"></i> <span>Customers</span> <b class="caret"></b></a>
                <ul class="dropdown-menu">
                       <li class="divider"></li>
                    <li><a class="icon icon-user" title="" href="cust_search.php"><i class="icon-play"></i>Search customer</a></li>
                       <li class="divider"></li>
                    <li><a class="sTrash" title="" href="cust_new.php"><i class="icon-play"></i>New customer</a></li>
                       <li class="divider"></li>
                    <li><a class="icon icon-envelope" title="" href="cust_act.php"><i class="icon-minus"></i>Active customer</a></li>
                       <li class="divider"></li>                   
               
                        <li><a class="sOutbox" title="" href="cust_inact.php"><i class="icon-play"></i>Inactive customer</a></li>
                        <li class="divider"></li>
                       
                </ul>
            </li>
              <li class=" dropdown" id="login"><a href="#"><i class="icon icon-envelope"></i> <span>Loans</span> <b class="caret"></b></a>
                   <ul class="dropdown-menu">
                       <li class="divider"></li>
                    <li><a class="icon icon-user" title="" href="loans_search.php"><i class="icon-play"></i>Loans search</a></li>
                       <li class="divider"></li>
                    <li><a class="sTrash" title="" href="loans_act.php"><i class="icon-play"></i>Loans active</a></li>
                       <li class="divider"></li>
                    <li><a class="icon icon-envelope" title="" href="loans_pend.php"><i class="icon-minus"></i>Loans pending</a></li>
                       <li class="divider"></li>                   
               
                        <li><a class="sOutbox" title="" href="loans_securities.php"><i class="icon-play"></i>Loans securities</a></li>
                        <li class="divider"></li>
                       
                </ul>
            </li>


                    <li class=" dropdown" id="login"><a href="#"><i class="icon icon-envelope"></i> <span>Finance</span> <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a class="icon icon-user" title="" href="#">My profile</a></li>
                    <li><a class="icon icon-envelope" title="" href="#">Chats</a></li>
                    <li><a class="sOutbox" title="" href="#">Documentation</a></li>
                    <li><a class="sTrash" title="" href="login.html">Logout</a></li>
                </ul>
            </li>
              <li class=" dropdown" id="login"><a href="#"><i class="icon icon-envelope"></i> <span>Employees</span> <b class="caret"></b></a>
                  <ul class="dropdown-menu">
                       <li class="divider"></li>
                    <li><a class="icon icon-user" title="" href="empl_curr.php"><i class="icon-play"></i>Current Employees</a>
                        </li>                    
                       <li class="divider"></li>
                    <li><a class="sTrash" title="" href="empl_past.php"><i class="icon-play"></i>Former Employees</a></li>
                       <li class="divider"></li>
                    <li><a class="icon icon-envelope" title="" href="empl_new.php"><i class="icon-minus"></i>Add Employee</a></li>
                       <li class="divider"></li>                   
                                      
                </ul>
            </li>

              <li class=" dropdown" id="login"><a href="#"><i class="icon icon-envelope"></i> <span>General reports</span> <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a class="icon icon-user" title="" href="#">My profile</a></li>
                    <li><a class="icon icon-envelope" title="" href="#">Chats</a></li>
                    <li><a class="sOutbox" title="" href="#">Documentation</a></li>
                    <li><a class="sTrash" title="" href="login.html">Logout</a></li>
                </ul>
            </li>
            
            <li class=" dropdown" id="login"><a href="#"><i class="icon icon-envelope"></i> <span>Settings</span> <b class="caret"></b></a>
                   <ul class="dropdown-menu">
                       <li class="divider"></li>
                    <li><a class="icon icon-user" title="" href="set_basic.php"><i class="icon-play"></i>General Settings</a>
                        </li>                    
                       <li class="divider"></li>
                    <li><a class="sTrash" title="" href="location.php"><i class="icon-play"></i>Add location</a></li>
                       <li class="divider"></li>
                    <li><a class="icon icon-envelope" title="" href="group.php"><i class="icon-minus"></i>Add group</a></li>
                       <li class="divider"></li>                   
                                      
                </ul>
            </li> 
          </ul>
    </div>