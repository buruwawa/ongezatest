<link rel="stylesheet" href="template/css/font.css">

		<!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800"> -->

<link href="template/css/bayanno.css" media="screen" rel="stylesheet" type="text/css" />
<script src="template/js/bayanno.js" type="text/javascript"></script>

        