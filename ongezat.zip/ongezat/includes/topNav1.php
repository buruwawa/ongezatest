   <!--top-Header-menu-->
    <div id="user-nav" class="navbar navbar-inverse">
        <ul class="nav">
                        <li class=""><a title="" href="logout.php"><i class="icon icon-share-alt"></i> <span
                        class="text">Logout</span></a></li>
         
            <li class=" dropdown" id="login"><a href="#" data-toggle="dropdown" data-target="#login"
                    class="dropdown-toggle"><i class="icon icon-envelope"></i> <span class="text">More</span> <span
                        class="label label-important">5</span> <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a class="" title="" href="#">My profile</a></li>
                    <li><a class="" title="" href="#">Chats</a></li>
                    <li><a class="sOutbox" title="" href="#">Documentation</a></li>
                    <li><a class="sTrash" title="" href="logout.php">Logout</a></li>
                </ul>
            </li>


        </ul>
    </div>