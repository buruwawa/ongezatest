   
    Menu to run the test
1:  Extrat the ongeza file and place under httdocs xampp/wamp folder
2:  http://localhost/ongezat/
3:  Click on the Question Tab to display the content